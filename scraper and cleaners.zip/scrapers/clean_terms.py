import csv

"""Simple command-line example for Custom Search.
Command-line application that does a search.
"""

__author__ = 'jcgregorio@google.com (Joe Gregorio)'

import pprint

from googleapiclient.discovery import build


def main():
  # Build a service object for interacting with the API. Visit
  # the Google APIs Console <http://code.google.com/apis/console>
  # to get an API key for your own application.

  csvfile = open("./unique_addresses.csv", "rU")
  restaurant_entry = csv.reader(csvfile)#, dialect=csv.excel_tab)
  with open('clean_addresses.csv', 'w') as csvfile:
    fieldnames = ['name', 'address','zipCode']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    i=0
    for row in restaurant_entry:
      name= row[0]
      address = row[1]
      zipCode = row[2]
      nm=name.lower()
      bad_terms = ["daycare", " mart", "day care", "childcare", "child care", "child care", "grocery","xfinity", "school", 
      "laundromat", "commissary", "preschool", "charter", "head start", "tobacco", "learning", "school", "pharmacy","education",
       "catering", "fitness", "walmart", "academy", "drug", "zoo", "nursing","rehab", "gnc", " market", "newspaper", "news", "dollar",
        "walgreens", "institute", "salvation", "depot", "hardware" ,"outlet", "hospital", "supermarket", " center", "cvs", "curbstand",
         "newstand", " inn", "bookstore", "rite aid", "rite - aid","truck","ross dress","florist","dentist","doctor","bicycles","cart","khan,","llc"," store"]
      wanted_terms = ["wawa" ,"cafe" ,"restaurant" ,"grille" ,"bar" ,"food market" ,"dong chun" ,"beer" ,"grill" ,"seafood"]   
      
      if any(term in nm for term in wanted_terms):
        writer.writerow({'name':name, 'address':row[1],'zipCode':row[2]})   
      elif any(term in nm for term in bad_terms):
        i+=1
        print name
      else:
        writer.writerow({'name':name, 'address':row[1],'zipCode':row[2]})
    print i

if __name__ == '__main__':
  main()