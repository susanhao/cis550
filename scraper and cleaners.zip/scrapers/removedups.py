import csv
import collections

def unique():
    rows = list(csv.reader(open('inspection-reports.csv', 'rU'),delimiter=',',dialect=csv.excel_tab))
    result = collections.OrderedDict()
    c = csv.writer(open('unique_addresses.csv', 'wb'))
    for r in rows:
    	if len(r)==0:
    		continue
        key = (r[0],r[1],r[2])
        if key not in result:
            result[key] = r
            c.writerow(key)

    return result.values()






from pprint import pprint
pprint(unique())