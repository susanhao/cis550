import rauth
import json
import csv
import sys
import urllib2
import lxml.etree
import lxml.html

#Paste your own API key here
api_key = 'eJcKIKWYQHe4KACL2TUsLV52TB+zIhIPME1eyri0CTI' 
#This is the request we will submit to Bing. The parameters begin afer the '?' character. 
#The main parameter we care about is the Query one, which tells Bing what to search for. 
#Once you have an account, you can explore the API more thoroughly here: https://datamarket.azure.com/dataset/explore/bing/search
requeststr = 'https://api.datamarket.azure.com/Bing/Search/v1/Web?Query=%%27%s%%27&$skip=%d' 

def get_urls(query, num_iters=1) : 
  """
  This is a method for collecting urls using the bing API.

  query- the query you want to issue to Bing search
  num_iters- the number of times to issue the command, helps to deal with pagination
  """
  #We have to give Bing our password. Python's urllib2 provides a nice class for doing this.
  credentials = 'Basic ' + (':%s' % api_key).encode('base64').strip()

  #Here, we will keep track of how many urls we have seen, so that we can paginate correctly.
  #I.e. if we have seen 10 urls, we want to issue another query telling Bing to start at the 11th url
  offset = 0
  for i in range(0,num_iters): 
    sys.stderr.write("Querying Bing (iteration %d out of %d)\n"%(i, num_iters))
    url = requeststr%(query, offset)

    #Here, we provide our password (API key) and then issue the request
    request = urllib2.Request(url)
    request.add_header('Authorization', credentials)
    requestOpener = urllib2.build_opener()
    response = requestOpener.open(request).read()

    #The query returns our results in ugly xml format. We can use the etree module to parse it
    doc = lxml.etree.HTML(response) 
    #This says only to look at the 'url' attribute of each entry
    result = doc.xpath("//entry//url")
    counter=0
    for item in result:
      counter+=1
      print item.text
      #keep track of how many items you are seeing, so you can pick up where you left off in the next iteration
      offset += 1 
      if counter==1:
        break
		#Be a good internet citizen and rate-limit yourself
		
	##Do other processing	

###YELP!
def get_results(params,row,elapsed):

	#Obtain these from Yelp's manage access page
  	consumer_key = "2GBPIKHCzXyeq_ZmZ5JM4g"
	consumer_secret = "cqLE80It2OoI_3Pt1TBYVEd1p_s"
	token = "bOUnCEn-89-l_oTpeNlzZxac_WUgPXnt"
	token_secret = "NSe8duEjaGtEUluLgaupq8UgQvA"
	
	session = rauth.OAuth1Session(
		consumer_key = consumer_key
		,consumer_secret = consumer_secret
		,access_token = token
		,access_token_secret = token_secret)
		
	request = session.get("http://api.yelp.com/v2/search",params=params)
	
	#Transforms the JSON API response into a Python dictionary
	data = request.json()
	
	for business in data['businesses']:
		print('.')
#		print(params["location"])
#		print(business["location"])
		try:
			if params["location"].split(" ")[0]==business["location"]["address"][0].split(" ")[0]:
				elapsed+=1
				print(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;")
				print(row[0])
				print(row[1]+" "+row[2])
				print(business["name"]+"            :Yelp Name")
				print(business["location"]["address"][0]+"            :Yelp address")
#				print("found: "+str(elapsed)+", total: "+str(total)+":   "+str(float(elapsed) / float(total)))
				newdata[row[1]+" "+row[2]]=business
				print(data)
		#json.dumps(business, indent=4, sort_keys=True)
		except IndexError:
			print('p')
			pass
	session.close()
	
	return data
		
def get_search_parameters(row):
	#See the Yelp API for more details
	params = {}
	#params["term"] = "Zio Pizza Palace & Grill"
	params["location"] = row[1]+" Philadelphia " +row[2]
	params["limit"] = "1"

	return params

locations = list(csv.reader(open('unique_addresses.csv', 'rU'),delimiter=',',dialect=csv.excel_tab))
api_calls = []
newdata={}
total=0

for row in locations:
	total+=1
	params = get_search_parameters(row)
	api_calls.append(get_results(params,row,0))
	if total==300:
		break
with open('data.json', 'w') as outfile:
	json.dump(newdata, outfile, indent=4, sort_keys=True, separators=(',', ':'))
