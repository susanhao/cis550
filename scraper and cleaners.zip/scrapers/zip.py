import rauth
import json
import csv
import sys
import urllib2
import lxml.etree
import lxml.html
import pprint

from googleapiclient.discovery import build

###YELP!
def get_results(yelp_id):

	#Obtain these from Yelp's manage access page
  	consumer_key = "2GBPIKHCzXyeq_ZmZ5JM4g"
	consumer_secret = "cqLE80It2OoI_3Pt1TBYVEd1p_s"
	token = "bOUnCEn-89-l_oTpeNlzZxac_WUgPXnt"
	token_secret = "NSe8duEjaGtEUluLgaupq8UgQvA"
	
	session = rauth.OAuth1Session(
		consumer_key = consumer_key
		,consumer_secret = consumer_secret
		,access_token = token
		,access_token_secret = token_secret)
		
	request = session.get("http://api.yelp.com/v2/business/"+yelp_id)
	
	#Transforms the JSON API response into a Python dictionary
	data = request.json()
	session.close()
	return data

    
# for row in locations:

# 	total+=1
# 	params = get_search_parameters(row)
# 	api_calls.append(get_results(params,row,elapsed))
# 	if total==300:
# 		break
# with open('data.json', 'w') as outfile:
# 	json.dump(newdata, outfile, indent=4, sort_keys=True, separators=(',', ':'))





if __name__ == '__main__': #Here we call the method, passing it a string as our query("shooting")
	yelp_ids = {}
	locations = list(csv.reader(open('unique_addresses.csv', 'rU'),delimiter=',',dialect=csv.excel_tab))
	counter=0
	for row in locations:
		counter+=1
		if counter==4:
			break;
		try:
			custom_url_query="site:yelp.com "+row[0]+" " + row[1] +" Philadelphia " +" " + row[2]
			#AIzaSyA51c6P1rDEA9O04vBpJratzWHhZQDnuJ0
			service = build("customsearch", "v1", developerKey="AIzaSyCck_eOO0O6gi_lmjzyQxu7V8EDkAhhwAM")
			res = service.cse().list(q=custom_url_query, cx='004637091528456480879:bqh_-5esqmk',).execute()
			yelp_id = res['items'][0]['formattedUrl'].split('/')[-1]
			print(yelp_id)
			result = get_results(yelp_id)
			print(result['id'])
			for key, value in result.iteritems() :
				if key=='error' or key==u'error':
					continue
				elif key=='name' or key==u'name':
				    print result[key]	
				if key=='location' or key==u'location':
					if key=='display_address' or key==u'display_address':
						print result[key]

			#print(result)
		#	for key, value in result.iteritems() :
		#	    print key, value
		#	if result[u'id']==u'BUSINESS_UNAVAILABLE':
		#		continue
		#	else:
		#		print("Address: "+result[u'location'][u'display_address'])
		#		print(result['rating'])
		#		print(result[u'rating'])
		#		print(result["rating"])
		except (KeyError,AttributeError,TypeError):
			pass



















