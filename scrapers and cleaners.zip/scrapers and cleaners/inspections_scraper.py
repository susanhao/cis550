import mechanize
import cookielib
from BeautifulSoup import BeautifulSoup
import html2text
import re

# Browser
br = mechanize.Browser()
# Cookie Jar
cj = cookielib.LWPCookieJar()
br.set_cookiejar(cj)

# Browser options
br.set_handle_equiv(True)
br.set_handle_gzip(True)
br.set_handle_redirect(True)
br.set_handle_referer(True)
br.set_handle_robots(False)
br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(), max_time=1)

br.addheaders = [('User-agent', 'Chrome')]

#with open('templates.txt', 'r') as f:
with open('restaurants.txt', 'r') as f:
    mylist = f.read().splitlines() 

#output_file = open('newOne.txt', 'a')

RestaurantAndInspection={}
RestaurantAndAddress={}

#restaurant name: (inspection date, link of report, list of violations)
for x in range(0,12601,1):
	link='http://pa.healthinspections.us/philadelphia/'+mylist[x]
	html=br.open(link).read()
	soup=BeautifulSoup(html)
	reports = soup.findAll('div',{'style':'border:1px solid #003399;width:95%;margin-bottom:10px;'})
	restaurantName = soup.findAll('div',{'style':'background-color:#003366;color:#FFFFFF;padding-left:5px;'})[0].find("b").text
	address = soup.findAll('div',{'style':'background-color:#EFEFEF;padding-left:5px;'})[0].text

	RestaurantAndAddress[restaurantName]=address
	inspections=[]
	for report in reports:
		d=report.findAll('div',{'style':'background-color:#EFEFEF;padding:5px;'})
		violationByCode={}
		for e in d:
			if re.findall('\d+', e.text):
				violationNumber = int(re.findall('\d+', e.text)[0])
				violationText=e.text.replace(str(violationNumber),"",1)
				if violationNumber in violationByCode:
					violationByCode[violationNumber].append(violationText)
				else:
					violationByCode[violationNumber]=[violationText]
		InspectionDate = report.findAll('div',{'style':'padding:5px;'})[0].text
		InspectionDate=InspectionDate.replace("Inspection Date:","",1)
		inspectionLink='http://pa.healthinspections.us/'+ report.findAll('a')[0]['href'].replace("../","",1)
		inspections.append((InspectionDate,inspectionLink,violationByCode))
	RestaurantAndInspection[restaurantName]=inspections
	print(RestaurantAndInspection[restaurantName][0][1])





#					copy.replace("small", "big")
#					output_file.write(copy+'\n')
#output_file.close()


def getZip(address):
	return int(re.findall('\d+$', address)[0])

def clean_address(address):
	new_address=address.replace("Philadelphia, PA","")
	new_address=new_address.replace("Philadelphia, pa","")
	new_address=new_address.replace("Philadelphia, Pa","")
	new_address=new_address.replace("philadelphia, pa","")
	new_address=new_address.replace("PHILADELPHIA, PA","")[:-6]
	return new_address
	







