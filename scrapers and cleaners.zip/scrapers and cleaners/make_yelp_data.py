import rauth
import json
import csv
import sys
import urllib2
import lxml.etree
import lxml.html
import pprint

from googleapiclient.discovery import build

###YELP!
def get_results(yelp_id):

  #Obtain these from Yelp's manage access page
  consumer_key = "2GBPIKHCzXyeq_ZmZ5JM4g"
  consumer_secret = "cqLE80It2OoI_3Pt1TBYVEd1p_s"
  token = "bOUnCEn-89-l_oTpeNlzZxac_WUgPXnt"
  token_secret = "NSe8duEjaGtEUluLgaupq8UgQvA"
  
  session = rauth.OAuth1Session(
    consumer_key = consumer_key
    ,consumer_secret = consumer_secret
    ,access_token = token
    ,access_token_secret = token_secret)
    
  request = session.get("http://api.yelp.com/v2/business/"+yelp_id)
  
  #Transforms the JSON API response into a Python dictionary
  data = request.json()
  session.close()
  return data

    
# for row in locations:

#   total+=1
#   params = get_search_parameters(row)
#   api_calls.append(get_results(params,row,elapsed))
#   if total==300:
#     break
# with open('data.json', 'w') as outfile:
#   json.dump(newdata, outfile, indent=4, sort_keys=True, separators=(',', ':'))




csvfile = open('yelp_data.csv', 'a')
fieldnames = ['name', 'address', 'zipCode', 'biz_id','json']
writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
writer.writeheader()

if __name__ == '__main__': #Here we call the method, passing it a string as our query("shooting")
  locations = list(csv.reader(open('restaurant_biz_ids.csv', 'rU'),delimiter=',',dialect=csv.excel_tab))
  counter=0
  i=0
  for row in locations:
    i+=1
    print i
    name = row[0]
    address = row[1]
    zipCode = row[2]
    biz_id = row[3]
    try:
      result = get_results(biz_id)
      #print(result['id'])
      bad_terms = ['convenience','tobaccoshops','drugstores','drycleaninglaundry','autorepair','artsupplies','museums','venues','shoppingcenters','retirement_homes','beer_and_wine','bookstores','weightlosscenters','computers','medcenters','adultentertainment','outlet_stores','preschools']
      if not any(term in result['categories'][0] for term in bad_terms):
        num = address.split(' ')[0]
        st = result['location']['address'][0]
        if num in st:
          print str(i)+': -------------- '
          writer.writerow({'name':row[0],'address':row[1],'zipCode':row[2],'biz_id':biz_id,'json':result})
        else:
          print str(i)+': wrong_address'
      else:
        print i+': invalid term!!'
    except (KeyError,AttributeError,TypeError,IndexError):
      print(str(i)+": error")
      pass



















