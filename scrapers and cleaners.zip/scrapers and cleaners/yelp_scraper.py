import csv
import pprint

from googleapiclient.discovery import build


def main():
  # Build a service object for interacting with the API. Visit
  # the Google APIs Console <http://code.google.com/apis/console>
  # to get an API key for your own application.
  service = build("customsearch", "v1", developerKey="API KEY REMOVED")


  addresses_csv = open('clean_addresses.csv', 'rU')
  restaurant_entries = csv.reader(addresses_csv)
  fieldnames = ['name', 'address', 'zipCode', 'biz_id']
  csvfile = open('temo_results5.csv', 'w')

  writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
  writer.writeheader()
  i=0

  for row in restaurant_entries:
    name= row[0]
    address = row[1]
    zipCode = row[2]
    res = service.cse().list( q='yelp '+row[0]+" "+row[1]+ ' Philadelphia PA '+row[2], cx='004637091528456480879:bqh_-5esqmk', ).execute()
    i+=1
    print i

    try:
      biz_id=res['items'][0]['formattedUrl'].split('/')[-1]
      #pprint.pprint(res['items'][0])
      shortname = name[0:4].lower()
      urls = [res['items'][0],res['items'][1],res['items'][2],res['items'][3]]
      if any('yelp' in url['formattedUrl'].lower() and shortname in url['htmlTitle'].lower() for url in urls):
        writer.writerow({'name':row[0],'address':row[1],'zipCode':row[2],'biz_id':biz_id})
    except KeyError:
      pprint.pprint("oh!: "+name)
      continue
    except UnicodeEncodeError:
      print('unicode!')
      continue
    

if __name__ == '__main__':
  main()